@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   TYMX: встановлення (потрібно один раз)
echo ============================================
echo.
set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if exist ".venv\Scripts\pythonw.exe" goto deps
echo [1/3] Створюю середовище Python у папці TYMX...
if exist "%PYEXE%" (
  "%PYEXE%" -m venv .venv
) else (
  py -3 -m venv .venv
)
if errorlevel 1 goto err
:deps
echo [2/3] Встановлюю бібліотеки, це 1-2 хвилини...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto err
echo [3/3] Створюю ярлик TYMX на робочому столі...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0make-shortcut.ps1"
if errorlevel 1 goto err
echo.
echo Готово! На робочому столі з'явився ярлик TYMX. Двічі клікни по ньому.
echo Це вікно можна закрити.
pause
exit /b 0
:err
echo.
echo ПОМИЛКА. Зроби скрін цього вікна і надішли мені.
pause
exit /b 1
