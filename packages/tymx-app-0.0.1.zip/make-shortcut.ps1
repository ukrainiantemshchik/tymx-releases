$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ws = New-Object -ComObject WScript.Shell
$desk = [Environment]::GetFolderPath('Desktop')
$lnk = $ws.CreateShortcut((Join-Path $desk 'TYMX.lnk'))
$lnk.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
$lnk.Arguments = '"' + (Join-Path $dir 'TYMX.vbs') + '"'
$lnk.WorkingDirectory = $dir
$lnk.IconLocation = (Join-Path $dir 'tymx-tx2.ico') + ',0'
$lnk.Description = 'TYMX antidetect browser'
$lnk.Save()
Write-Host ('OK: ' + (Join-Path $desk 'TYMX.lnk'))
