"""Запуск TYMX. Уся логіка в tymx/runner.py (у готовій збірці вона без вихідного коду)."""
from tymx.runner import main

if __name__ == "__main__":
    main()
