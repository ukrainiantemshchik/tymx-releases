@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Запуск TYMX з чорним вікном: тут видно всі повідомлення та помилки.
if not exist ".venv\Scripts\python.exe" (
  echo Спершу запусти install.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" run.py %*
pause
