"use strict";
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const flag = cc => cc && cc.length === 2 ? String.fromCodePoint(...[...cc.toUpperCase()].map(c => 127397 + c.charCodeAt(0))) : "";
const fmtTime = ts => { if (!ts) return "—"; const d = new Date(ts * 1000), p = n => String(n).padStart(2, "0"); return `${p(d.getDate())}.${p(d.getMonth() + 1)} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; };

const S = { page: "profiles", tab: "profiles", search: "", group: "", pageNo: 1, size: 50, sel: new Set(), data: { items: [], total: 0, queue: {}, groups: [] }, opening: new Set() };

function toast(msg, err) {
  const el = document.createElement("div"); if (err) el.className = "err"; el.textContent = msg;
  $("#toast").appendChild(el); setTimeout(() => el.remove(), err ? 9000 : 4000);
}
async function api(method, path, body) {
  const r = await fetch(path, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { toast(j.error || j.msg || "помилка", true); throw new Error(j.error || "http " + r.status); }
  return j;
}

// ---------- модалки ----------
function modal(html, onMount) {
  const root = $("#modal-root"); root.innerHTML = `<div class="back"><div class="modal">${html}</div></div>`;
  const back = $(".back", root); back.addEventListener("mousedown", e => { if (e.target === back) closeModal(); });
  onMount && onMount($(".modal", root));
}
function closeModal() { $("#modal-root").innerHTML = ""; }
const modalOpen = () => !!$("#modal-root .back");
function askText(title, initial = "") {
  return new Promise(res => modal(`<h2>${esc(title)}</h2><div class="field"><input id="q" value="${esc(initial)}"></div>
    <div class="actions"><button class="btn" id="c">Скасувати</button><button class="btn primary" id="o">Гаразд</button></div>`, m => {
    const q = $("#q", m); q.focus(); q.select();
    $("#c", m).onclick = () => { closeModal(); res(null); }; $("#o", m).onclick = () => { closeModal(); res(q.value.trim()); };
    q.onkeydown = e => { if (e.key === "Enter") $("#o", m).click(); };
  }));
}
function confirmBox(text) {
  return new Promise(res => modal(`<h2>${esc(text)}</h2><div class="actions"><button class="btn" id="c">Скасувати</button><button class="btn primary" id="o">Так</button></div>`, m => {
    $("#c", m).onclick = () => { closeModal(); res(false); }; $("#o", m).onclick = () => { closeModal(); res(true); };
  }));
}

// ---------- меню ----------
function menu(anchor, items) {
  document.querySelectorAll(".menu").forEach(m => m.remove());
  const m = document.createElement("div"); m.className = "menu";
  m.innerHTML = items.map((it, i) => `<a data-i="${i}" class="${it.danger ? "danger" : ""}">${esc(it.label)}</a>`).join("");
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.min(r.right - 210, innerWidth - 230) + "px";
  m.style.top = Math.min(r.bottom + 4, innerHeight - m.offsetHeight - 10) + "px";
  m.onclick = e => { const a = e.target.closest("a"); if (a) { m.remove(); items[+a.dataset.i].fn(); } };
  setTimeout(() => document.addEventListener("click", () => m.remove(), { once: true }), 0);
}

// ---------- навігація ----------
document.querySelectorAll("#nav a").forEach(a => a.onclick = () => go(a.dataset.page));
// групи меню згортаються, як в AdsPower; стан запам'ятовується
const GRP_DEFAULT_CLOSED = ["auto", "team"];
let grpClosed; try { grpClosed = JSON.parse(localStorage.getItem("tymx-closed-groups")); } catch { }
if (!Array.isArray(grpClosed)) grpClosed = GRP_DEFAULT_CLOSED;
document.querySelectorAll("#nav .grp").forEach(g => {
  g.classList.toggle("closed", grpClosed.includes(g.dataset.grp));
  g.querySelector(".grp-h").onclick = () => {
    g.classList.toggle("closed");
    const closed = [...document.querySelectorAll("#nav .grp.closed")].map(x => x.dataset.grp);
    try { localStorage.setItem("tymx-closed-groups", JSON.stringify(closed)); } catch { }
  };
});
$("#btn-new").onclick = () => profileForm();
const TITLES = { profiles: "Профілі", groups: "Групи", proxies: "Проксі", extensions: "Розширення", trash: "Кошик",
  sync: "Синхронізатор", rpa: "Сценарії (RPA)", schedule: "Розклад", api: "API для ботів", telegram: "Telegram-керування",
  team: "Учасники", roles: "Ролі й доступи", billing: "Тариф і оплата",
  engines: "Ядра браузера", gate: "Safety gate", journal: "Журнал запусків", backups: "Резервні копії", settings: "Налаштування" };
const SOON = {
  extensions: "Встановлення розширень (MetaMask, Phantom тощо) одразу в усі або вибрані профілі.",
  sync: "Повторення дій з одного вікна одразу в кількох профілях: кліки, введення тексту, прокрутка.",
  rpa: "Готові сценарії без коду: відкрити сайт, натиснути, ввести, зачекати. Запуск на групі профілів.",
  schedule: "Запуск профілів і сценаріїв за часом: наприклад, щодня о 9:00 відкрити групу Kraken.",
  telegram: "Керування TYMX з Telegram: відкрити або закрити профілі, отримати звіт про помилки.",
  team: "Спільна робота: запросити людей і дати їм доступ до вибраних груп профілів.",
  roles: "Хто що може: власник, менеджер, оператор. Обмеження на видалення й експорт.",
  billing: "Тарифи й оплата, коли TYMX стане сервісом для інших. Потрібен онлайн-сервер.",
  backups: "Збереження всіх профілів і бази в один архів і відновлення з нього.",
};
function go(page) {
  S.page = page;
  document.querySelectorAll("#nav a").forEach(a => a.classList.toggle("active", a.dataset.page === page));
  $("#title").textContent = TITLES[page];
  if (page === "profiles" || page === "trash") { const t = page === "trash" ? "trash" : "profiles"; if (S.tab !== t) { S.tab = t; S.sel.clear(); S.pageNo = 1; S.group = ""; } return renderProfiles(); }
  if (SOON[page]) return renderSoon(page);
  ({ groups: renderGroups, proxies: renderProxies, engines: renderEngines, settings: renderSettings, api: renderApi, journal: renderJournal, gate: renderGate })[page]();
}
function renderSoon(page) {
  $("#page").innerHTML = `<div class="soon"><span class="tag">Скоро</span><h2>${esc(TITLES[page])}</h2><p>${esc(SOON[page])}</p><p>Цей розділ з'явиться в одній із наступних версій TYMX.</p></div>`;
}

// ---------- ПРОФІЛІ ----------
function renderProfiles() {
  const trash = S.tab === "trash";
  $("#page").innerHTML = `${trash ? "" : `<div class="tabs" id="gtabs"></div>`}<div id="ptab"></div>`;
  $("#ptab").style.cssText = "display:flex;flex-direction:column;flex:1;min-height:0";
  $("#ptab").innerHTML = `
  <div class="filters" style="${trash ? "margin-top:14px" : ""}">
    <input class="search" id="f-search" placeholder="Пошук: ім'я, ID, №, IP, нотатки…" value="${esc(S.search)}">
  </div>
  <div class="toolbar" id="toolbar"></div>
  <div class="tablewrap"><table><thead><tr>
    <th style="width:34px"><input type="checkbox" id="chk-all"></th><th>№</th><th>ID</th><th>Група</th><th>Ім'я</th><th>IP</th><th>Safety gate</th><th>Останній запуск</th><th>Нотатки</th><th style="text-align:right">Операція</th>
  </tr></thead><tbody id="rows"></tbody></table></div>
  <div class="foot"><span id="total"></span><button class="btn" id="prev">‹</button><span id="pageno"></span><button class="btn" id="next">›</button>
    <select id="size"><option>25</option><option>50</option><option>100</option></select></div>`;
  $("#f-search").oninput = e => { S.search = e.target.value; S.pageNo = 1; clearTimeout(S.st); S.st = setTimeout(refresh, 250); };
  $("#size").value = S.size; $("#size").onchange = e => { S.size = +e.target.value; S.pageNo = 1; refresh(); };
  $("#prev").onclick = () => { if (S.pageNo > 1) { S.pageNo--; refresh(); } };
  $("#next").onclick = () => { if (S.pageNo * S.size < S.data.total) { S.pageNo++; refresh(); } };
  $("#chk-all").onchange = e => { S.data.items.forEach(i => e.target.checked ? S.sel.add(i.id) : S.sel.delete(i.id)); drawRows(); drawToolbar(); };
  refresh();
}

async function refresh() {
  if (S.page !== "profiles" && S.page !== "trash") { drawSide(); return; }
  const q = new URLSearchParams({ page: S.pageNo, size: S.size, search: S.search, group: S.group, deleted: S.tab === "trash" ? 1 : 0 });
  try { S.data = await (await fetch("/ui-api/profiles?" + q)).json(); } catch { $("#api-chip").textContent = "API офлайн"; $("#api-chip").classList.remove("on"); return; }
  $("#api-chip").textContent = `API :${location.port} · онлайн`; $("#api-chip").classList.add("on");
  if (!S.search && !S.group && S.tab === "profiles") S.allTotal = S.data.total;
  drawTabs(); drawRows(); drawToolbar(); drawSide();
}

function drawTabs() {
  const t = $("#gtabs"); if (!t) return;
  const tabs = [["", "Усі"], ...S.data.groups.map(g => [g, g])];
  t.innerHTML = tabs.map(([v, l]) => `<a data-g="${esc(v)}" class="${v === S.group ? "active" : ""}">${esc(l)}${v === "" && S.allTotal != null ? `<span class="cnt">${S.allTotal}</span>` : ""}</a>`).join("");
  t.querySelectorAll("a").forEach(a => a.onclick = () => { S.group = a.dataset.g; S.pageNo = 1; S.sel.clear(); refresh(); });
}

function gateBadge(p) {
  if (p.queued) return `<span class="badge wait">⏳ у черзі</span>`;
  if (S.opening.has(p.id)) return `<span class="badge wait">… перевірка</span>`;
  if (!p.last_gate) return `<span class="badge">ще не відкривався</span>`;
  if (p.last_gate.ok) return `<span class="badge ok" title="Усі перевірки пройдено">✔ пройдено</span>`;
  const bad = p.last_gate.detail.filter(c => !c.ok);
  return `<span class="badge bad" data-gate="${p.id}" title="${esc(bad.map(c => c.name + ": " + c.detail).join("\n"))}">✖ відмова: ${esc(bad[0]?.name || "")}</span>`;
}

function drawRows() {
  const tb = $("#rows"); if (!tb) return;
  const trash = S.tab === "trash";
  if (!S.data.items.length) { tb.innerHTML = `<tr><td colspan="10" class="empty">${trash ? "Сміття порожнє" : "Профілів ще немає. Натисни «Новий профіль»."}</td></tr>`; }
  else tb.innerHTML = S.data.items.map(p => `
    <tr data-id="${p.id}">
      <td><input type="checkbox" class="sel" ${S.sel.has(p.id) ? "checked" : ""}></td>
      <td class="num">${p.seq}</td><td class="mono">${p.id}</td><td>${esc(p.group_name) || "—"}</td>
      <td><b>${esc(p.name)}</b>${p.canary ? '<span class="badge canary" title="Канарковий профіль: першим отримує нове ядро">canary</span>' : ""}</td>
      <td>${p.proxy_ip ? `<div class="ip"><span><span class="dot ${p.proxy_status === "ok" ? "ok" : p.proxy_status === "dead" ? "bad" : ""}"></span>${esc(p.proxy_ip)}</span><small>${flag(p.country)} ${esc(p.country || "")} · ${esc(p.timezone || "")}</small></div>`
        : `<div class="ip"><span><span class="dot"></span>${p.proxy_host ? esc(p.proxy_host) + ":" + p.proxy_port : "без проксі"}</span><small>${flag(p.country)} ${esc(p.country || "")}</small></div>`}</td>
      <td>${gateBadge(p)}</td>
      <td>${fmtTime(p.last_open_at)}</td><td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.notes)}">${esc(p.notes) || "—"}</td>
      <td style="text-align:right;white-space:nowrap">${trash ? `<button class="btn sm" data-act="restore">Відновити</button> <button class="btn sm danger" data-act="purge">Видалити назавжди</button>`
        : `${p.running ? `<button class="btn sm close" data-act="close">■ Закрити</button>` : `<button class="btn sm primary" data-act="open" ${S.opening.has(p.id) || p.queued ? "disabled" : ""}>▶ Відкрити</button>`}
           <button class="btn sm" data-act="menu">⋮</button>`}</td>
    </tr>`).join("");
  tb.querySelectorAll("tr[data-id]").forEach(tr => {
    const id = tr.dataset.id, p = S.data.items.find(x => x.id === id);
    tr.querySelector(".sel").onchange = e => { e.target.checked ? S.sel.add(id) : S.sel.delete(id); drawToolbar(); };
    tr.querySelectorAll("[data-act]").forEach(b => b.onclick = e => rowAction(b.dataset.act, p, b));
    const gb = tr.querySelector("[data-gate]"); if (gb) gb.onclick = () => showGate(p);
  });
  const total = S.data.total, from = total ? (S.pageNo - 1) * S.size + 1 : 0;
  $("#total").textContent = `Всього: ${total}`; $("#pageno").textContent = `${S.pageNo} / ${Math.max(1, Math.ceil(total / S.size))}`;
}

function drawToolbar() {
  const t = $("#toolbar"); if (!t) return;
  const n = S.sel.size, trash = S.tab === "trash";
  if (trash) { t.innerHTML = `<button class="btn" id="b-restore" ${n ? "" : "disabled"}>Відновити (${n})</button><button class="btn danger" id="b-purge" ${n ? "" : "disabled"}>Видалити назавжди (${n})</button>`;
    $("#b-restore").onclick = () => bulk("restore"); $("#b-purge").onclick = async () => { if (await confirmBox(`Видалити назавжди ${n} профілів разом із папками?`)) bulk("purge"); }; return; }
  t.innerHTML = `<button class="btn primary" id="b-open" ${n ? "" : "disabled"}>▶ Відкрити (${n})</button>
    <button class="btn" id="b-close" ${n ? "" : "disabled"}>■ Закрити</button>
    <button class="btn" id="b-group" ${n ? "" : "disabled"}>Група…</button>
    <button class="btn" id="b-canary" ${n ? "" : "disabled"}>Canary</button>
    <button class="btn danger" id="b-del" ${n ? "" : "disabled"}>У сміття</button>
    <span class="sp"></span><button class="btn" id="b-refresh" title="Оновити">⟳</button>`;
  $("#b-open").onclick = () => { S.sel.forEach(id => S.opening.add(id)); bulk("open"); toast("Відкриваю через чергу…"); };
  $("#b-close").onclick = () => bulk("close");
  $("#b-group").onclick = async () => { const g = await askText("Назва групи", ""); if (g !== null) bulk("group", { group: g }); };
  $("#b-canary").onclick = e => menu(e.currentTarget, [{ label: "Зробити canary (перші на новому ядрі)", fn: () => bulk("canary", { value: true }) }, { label: "Зняти canary", fn: () => bulk("canary", { value: false }) }]);
  $("#b-del").onclick = () => bulk("trash");
  $("#b-refresh").onclick = refresh;
}
async function bulk(action, extra = {}) {
  const ids = [...S.sel];
  await api("POST", "/ui-api/profiles/bulk", { action, ids, ...extra });
  if (["trash", "purge", "restore"].includes(action)) S.sel.clear();
  setTimeout(() => { ids.forEach(i => S.opening.delete(i)); refresh(); }, action === "open" ? 1500 : 0);
  refresh();
}

async function rowAction(act, p, btn) {
  if (act === "open") {
    S.opening.add(p.id); drawRows();
    try {
      const r = await api("POST", `/ui-api/profiles/${p.id}/open`);
      if (r.code === 0) toast(`Профіль ${p.seq} відкрито`);
      else toast(`Профіль ${p.seq} НЕ відкрито: ${r.msg}`, true);
    } finally { S.opening.delete(p.id); refresh(); }
  } else if (act === "close") { await api("POST", `/ui-api/profiles/${p.id}/close`); refresh(); }
  else if (act === "restore") { await api("POST", "/ui-api/profiles/bulk", { action: "restore", ids: [p.id] }); refresh(); }
  else if (act === "purge") { if (await confirmBox(`Видалити профіль ${p.seq} назавжди разом із папкою?`)) { await api("POST", "/ui-api/profiles/bulk", { action: "purge", ids: [p.id] }); refresh(); } }
  else if (act === "menu") menu(btn, [
    { label: "Редагувати / змінити проксі", fn: () => profileForm(p) },
    { label: "Синхронізувати гео з проксі", fn: async () => { try { const r = await api("POST", `/ui-api/profiles/${p.id}/resync-geo`); toast(`Гео оновлено: ${r.geo.country} ${r.geo.timezone}`); refresh(); } catch { } } },
    { label: p.canary ? "Зняти canary" : "Зробити canary", fn: async () => { await api("PATCH", `/ui-api/profiles/${p.id}`, { canary: !p.canary }); refresh(); } },
    { label: "Історія перевірок", fn: () => showGate(p) },
    { label: "У сміття", danger: true, fn: async () => { await api("POST", "/ui-api/profiles/bulk", { action: "trash", ids: [p.id] }); refresh(); } },
  ]);
}

async function showGate(p) {
  const ev = await (await fetch(`/ui-api/profiles/${p.id}/events`)).json();
  modal(`<h2>Перевірки профілю ${p.seq} · ${esc(p.name)}</h2><div class="gate">` +
    (ev.filter(e => e.kind === "open").slice(0, 6).map(e => `<div class="card" style="margin-bottom:10px"><b class="${e.ok ? "ok-t" : "bad-t"}">${e.ok ? "✔ відкрито" : "✖ відмова"}</b> <span class="mono">${fmtTime(e.ts)}</span><ul>` +
      e.detail.map(c => `<li><span class="${c.ok ? "ok-t" : "bad-t"}">${c.ok ? "✔" : "✖"}</span> <b>${esc(c.name)}</b> — ${esc(c.detail)}</li>`).join("") + `</ul></div>`).join("") || "<p class='note'>Ще не було спроб відкриття.</p>") +
    `</div><div class="actions"><button class="btn primary" id="x">Закрити</button></div>`, m => $("#x", m).onclick = closeModal);
}

const OS_ICON = {
  windows: `<svg viewBox="0 0 16 16" width="16" height="16"><path fill="currentColor" d="M0 2.2 6.5 1.3v6.2H0zM7.3 1.2 16 0v7.5H7.3zM0 8.3h6.5v6.3L0 13.7zM7.3 8.3H16V16l-8.7-1.2z"/></svg>`,
  macos: `<svg viewBox="0 0 16 16" width="16" height="16"><path fill="currentColor" d="M11.2 0c.1 1-.3 2-.9 2.7-.6.7-1.6 1.3-2.5 1.2-.1-1 .4-2 .9-2.6C9.4.6 10.4.1 11.2 0zM14 11.6c-.4.9-.6 1.3-1.1 2.1-.7 1.1-1.7 2.3-2.9 2.3-1.1 0-1.4-.7-2.8-.7-1.5 0-1.8.7-2.9.7-1.2 0-2.2-1.2-2.9-2.3C-.5 10.7-.7 7 .6 5c.9-1.4 2.3-2.2 3.6-2.2 1.4 0 2.2.7 3.3.7 1.1 0 1.8-.7 3.3-.7 1.2 0 2.4.6 3.3 1.7-2.9 1.6-2.4 5.7-.1 7.1z"/></svg>`,
};
const OS_NAME = { windows: "Windows", macos: "macOS" };
const CPU = { windows: [4, 6, 8, 12, 16], macos: [8, 10, 12] };
const uaFor = (os, ver) => `Mozilla/5.0 (${os === "macos" ? "Macintosh; Intel Mac OS X 10_15_7" : "Windows NT 10.0; Win64; x64"}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${(ver || "148").split(".")[0]}.0.0.0 Safari/537.36`;

async function profileForm(p) {
  const proxies = await (await fetch("/ui-api/proxies")).json();
  const engs = (await (await fetch("/ui-api/engines")).json()).filter(e => e.status === "approved" || e.status === "retired");
  const groups = S.data.groups || [];
  const edit = !!p;
  const fp0 = p?.fingerprint || null;
  const F = { os: fp0?.platform || "windows", hw: fp0 ? { screen: fp0.screen, cores: fp0.cores, memory: fp0.memory } : null };
  if (!edit) {
    const pr = await (await fetch("/ui-api/fp/preview")).json();
    F.os = pr.platform; F.hw = { screen: pr.screen, cores: pr.cores, memory: pr.memory };
  }
  const tab = (id, title) => `<a data-t="${id}">${title}</a>`;
  modal(`<h2>${edit ? "Редагувати профіль" : "Новий профіль"}</h2>
    <div class="tabs pf-tabs">${tab("gen", "Загальний")}${tab("proxy", "Проксі")}${tab("fp", "Відбиток")}${tab("adv", "Просунутий")}</div>
    <div class="pf">
     <div class="pf-main">
      <section data-p="gen">
        <div class="two"><div class="field"><label>Ім'я</label><input id="f-name" maxlength="100" value="${esc(p?.name || "")}" placeholder="напр. TikTok 01"></div>
        ${edit ? `<div class="field"><label>№ / ID</label><input disabled value="${p.seq} / ${esc(p.id)}"></div>` : `<div class="field"><label>Скільки створити</label><input id="f-count" type="number" min="1" max="100" value="1"></div>`}</div>
        <div class="field"><label>ОС</label><div class="seg" id="f-os">${["windows", "macos"].map(o => `<button type="button" data-os="${o}" ${edit ? "disabled" : ""}>${OS_ICON[o]}<span>${OS_NAME[o]}</span></button>`).join("")}</div></div>
        <p class="hint" id="f-os-hint"></p>
        <div class="field"><label>Група</label><input id="f-group" list="gl" value="${esc(p?.group_name || "")}" placeholder="Без групи"><datalist id="gl">${groups.map(g => `<option>${esc(g)}</option>`).join("")}</datalist></div>
        <div class="field"><label>Cookie</label><textarea id="f-cookies" rows="3" placeholder="Формати: JSON (EditThisCookie, Cookie-Editor) або Netscape cookies.txt"></textarea></div>
        <p class="hint">Cookie поставляться при першому відкритті профілю.${edit && p.pending_cookies ? ` Вже чекають імпорту: ${p.pending_cookies}.` : ""}</p>
        <div class="field"><label>Нотатки</label><textarea id="f-notes" rows="2" maxlength="2000" placeholder="Введи примітку">${esc(p?.notes || "")}</textarea></div>
      </section>
      <section data-p="proxy">
        <div class="field"><label>Проксі зі списку</label><select id="f-proxy"><option value="">${edit ? "— не змінювати —" : "— не вибрано —"}</option>${proxies.map(x => `<option value="${x.id}" ${p?.proxy_id === x.id ? "selected" : ""}>${esc(x.type)}://${esc(x.host)}:${x.port} ${x.country ? "· " + x.country : ""} ${x.used ? `(використ.: ${x.used})` : ""}</option>`).join("")}</select></div>
        <div class="field"><label>…або встав новий проксі</label><input id="f-line" placeholder="host:port:логін:пароль   або   socks5://логін:пароль@host:port"></div>
        <p class="hint">Країна, мова, часовий пояс і місцезнаходження беруться з IP проксі автоматично.${edit ? " Якщо поміняєш проксі на іншу країну, мова й пояс профілю оновляться." : ""}</p>
        <div class="check"><input type="checkbox" id="f-req" ${p && !p.proxy_required ? "" : "checked"}><span>Проксі обов'язкове<small>Без проксі профіль не відкриється (безпечніше). Зніми галочку, щоб працювати з твого IP: країна й пояс візьмуться з нього.</small></span></div>
      </section>
      <section data-p="fp">
        <div class="field"><label>Ядро браузера</label><select id="f-engine"><option value="">Автоматично: найновіше схвалене</option>${engs.map(e => `<option value="${e.id}" ${p?.engine_id === e.id ? "selected" : ""}>Chrome ${esc(e.full_version || e.version)}${e.status === "approved" ? " (основне)" : ""}</option>`).join("")}</select></div>
        <div class="two"><div class="field"><label>Ядер CPU</label><select id="f-cores" ${edit ? "disabled" : ""}></select></div><div></div></div>
        <p class="hint">Екран сайти бачать справжній, як у твого комп'ютера: ядро його не підміняє, тому TYMX і не обіцяє іншого.</p>
        ${edit ? `<p class="hint">Відбиток уже створений і не змінюється: так акаунт не бачить «нового» пристрою.</p>` : `<button type="button" class="btn" id="f-regen">🔀 Новий відбиток</button>`}
      </section>
      <section data-p="adv">
        <div class="check"><input type="checkbox" id="f-canary" ${p?.canary ? "checked" : ""}><span>Canary-профіль<small>Нову версію ядра спершу отримують лише такі профілі.</small></span></div>
        <p class="hint">Захист вмикається сам для кожного профілю: WebRTC іде лише через проксі, Canvas, WebGL, аудіо й шрифти мають унікальний шум, а перед кожним відкриттям TYMX звіряє ядро, проксі й відбиток.</p>
      </section>
     </div>
     <div class="pf-sum"><h3>Підсумок профілю</h3><div id="f-sum"></div></div>
    </div>
    <div class="actions"><button class="btn" id="c">Скасувати</button><button class="btn primary" id="ok">${edit ? "Зберегти" : "Створити"}</button></div>`, m => {
    m.classList.add("wide");
    const show = t => { m.querySelectorAll(".pf-tabs a").forEach(a => a.classList.toggle("active", a.dataset.t === t));
      m.querySelectorAll(".pf-main section").forEach(s => s.hidden = s.dataset.p !== t); };
    m.querySelectorAll(".pf-tabs a").forEach(a => a.onclick = () => show(a.dataset.t)); show("gen");
    const fillHw = () => {
      const cp = $("#f-cores", m);
      cp.innerHTML = [...new Set([F.hw.cores, ...CPU[F.os]])].sort((a, b) => a - b).map(x => `<option ${x === F.hw.cores ? "selected" : ""}>${x}</option>`).join("");
    };
    const sum = () => {
      const eng = engs.find(e => e.id === +$("#f-engine", m).value) || engs.find(e => e.status === "approved") || engs[0];
      const ver = eng ? (eng.full_version || eng.version) : "";
      const line = $("#f-line", m).value.trim(), pxSel = proxies.find(x => x.id === +$("#f-proxy", m).value);
      const pxCur = edit && p.proxy_id ? proxies.find(x => x.id === p.proxy_id) : null;
      const px = line ? "новий (перевірю при створенні)" : pxSel ? `${pxSel.type.toUpperCase()} ${pxSel.host}` : pxCur ? `${pxCur.type.toUpperCase()} ${pxCur.host}` : ($("#f-req", m).checked ? "потрібне, ще не вибране" : "твій IP");
      const many = !edit && +($("#f-count", m).value || 1) > 1;
      const geo = edit && fp0 ? null : "На основі IP";
      const rows = [["Ядро", ver ? `Chrome ${ver}` : "--"], ["ОС", OS_NAME[F.os]], ["User-Agent", uaFor(F.os, ver)], ["Проксі", px],
        ["WebRTC", "лише через проксі"], ["Часовий пояс", geo || fp0.timezone], ["Місцезнаходження", geo || p.country || "--"],
        ["Мова", geo || (fp0.languages || []).join(", ")],
        ["Екран", "справжній, як у комп'ютера"], ["Ядер CPU", many ? "випадково для кожного" : F.hw.cores],
        ["Canvas", "шум (унікальний)"], ["WebGL", "шум (унікальний)"], ["Аудіо", "шум (унікальний)"],
        ["Cookie", $("#f-cookies", m).value.trim() ? "буде імпортовано" : (edit && p.pending_cookies ? `чекають: ${p.pending_cookies}` : "немає")]];
      $("#f-sum", m).innerHTML = rows.map(([k, v]) => `<div class="r"><span>${k}</span><b>${esc(v)}</b></div>`).join("");
      m.querySelectorAll("#f-os button").forEach(b => b.classList.toggle("on", b.dataset.os === F.os));
      const host = navigator.platform.toLowerCase().includes("mac") ? "macos" : "windows";
      $("#f-os-hint", m).textContent = F.os !== host && !edit ? `Комп'ютер працює на ${OS_NAME[host]}: шрифти й відеокарта будуть від нього, тож уважні сайти можуть помітити різницю. Надійніше ${OS_NAME[host]}.` : "";
    };
    const regen = async () => { const pr = await (await fetch("/ui-api/fp/preview?platform=" + F.os)).json(); F.hw = { screen: pr.screen, cores: pr.cores, memory: pr.memory }; fillHw(); sum(); };
    m.querySelectorAll("#f-os button").forEach(b => b.onclick = () => { if (F.os !== b.dataset.os) { F.os = b.dataset.os; regen(); } });
    if (!edit) $("#f-regen", m).onclick = regen;
    $("#f-cores", m).onchange = e => { F.hw.cores = +e.target.value; sum(); };
    m.addEventListener("input", sum); m.addEventListener("change", sum);
    fillHw(); sum();
    $("#c", m).onclick = closeModal;
    $("#ok", m).onclick = async () => {
      const body = { name: $("#f-name", m).value.trim() || "Профіль", group: $("#f-group", m).value.trim(), notes: $("#f-notes", m).value,
        canary: $("#f-canary", m).checked, proxy_required: $("#f-req", m).checked, engine_id: +$("#f-engine", m).value || null };
      const line = $("#f-line", m).value.trim(), pid = $("#f-proxy", m).value, cookies = $("#f-cookies", m).value.trim();
      $("#ok", m).disabled = true; $("#ok", m).textContent = line || pid ? "Перевіряю проксі…" : "Зберігаю…";
      try {
        if (edit) {
          const patch = { name: body.name, group_name: body.group, notes: body.notes, canary: body.canary, proxy_required: body.proxy_required, engine_id: body.engine_id };
          if (line) patch.proxy_line = line; else if (pid) patch.proxy_id = +pid;
          if (cookies) patch.cookies = cookies;
          await api("PATCH", `/ui-api/profiles/${p.id}`, patch);
        } else {
          if (line) body.proxy_line = line; else if (pid) body.proxy_id = +pid;
          Object.assign(body, { count: +($("#f-count", m).value || 1), platform: F.os, hw: F.hw, cookies });
          await api("POST", "/ui-api/profiles", body);
        }
        closeModal(); refresh(); toast(edit ? "Збережено" : "Профіль створено");
      } catch { $("#ok", m).disabled = false; $("#ok", m).textContent = edit ? "Зберегти" : "Створити"; }
    };
  });
}

async function renderGroups() {
  const g = await (await fetch("/ui-api/groups")).json();
  $("#page").innerHTML = `<div class="toolbar" style="margin-top:14px"><button class="btn primary" id="g-add">＋ Нова група</button></div>
    <div class="cards">${g.map(x => `<div class="card"><b>${esc(x)}</b></div>`).join("") || '<div class="empty">Груп ще немає</div>'}</div>`;
  $("#g-add").onclick = async () => { const n = await askText("Назва нової групи"); if (n) { await api("POST", "/ui-api/groups", { name: n }); renderGroups(); } };
}

// ---------- ПРОКСІ ----------
async function renderProxies() {
  const list = await (await fetch("/ui-api/proxies")).json();
  $("#page").innerHTML = `<div class="toolbar" style="margin-top:12px"><button class="btn primary" id="p-add">＋ Додати проксі</button><button class="btn" id="p-all">Перевірити всі</button></div>
  <div class="tablewrap"><table><thead><tr><th>ID</th><th>Тип</th><th>Адреса</th><th>Логін</th><th>Вихідний IP</th><th>Країна · пояс</th><th>Стан</th><th>Профілів</th><th style="text-align:right">Операція</th></tr></thead><tbody>
  ${list.map(x => `<tr><td class="num">${x.id}</td><td>${esc(x.type)}</td><td class="mono">${esc(x.host)}:${x.port}</td><td>${esc(x.username) || "—"}</td><td>${esc(x.ip) || "—"}</td>
    <td>${flag(x.country)} ${esc(x.country || "")} ${x.timezone ? "· " + esc(x.timezone) : ""}</td>
    <td><span class="badge ${x.status === "ok" ? "ok" : x.status === "dead" ? "bad" : ""}">${x.status === "ok" ? "працює" : x.status === "dead" ? "не працює" : "не перевірено"}</span></td><td>${x.used}</td>
    <td style="text-align:right"><button class="btn sm" data-chk="${x.id}">Перевірити</button> <button class="btn sm danger" data-del="${x.id}">✕</button></td></tr>`).join("") || `<tr><td colspan="9" class="empty">Проксі ще немає</td></tr>`}
  </tbody></table></div>`;
  document.querySelectorAll("[data-chk]").forEach(b => b.onclick = async () => { b.textContent = "…"; try { await api("POST", `/ui-api/proxies/${b.dataset.chk}/check`); } catch { } renderProxies(); });
  document.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => { try { await api("DELETE", `/ui-api/proxies/${b.dataset.del}`); } catch { } renderProxies(); });
  $("#p-all").onclick = async () => { for (const x of list) { try { await api("POST", `/ui-api/proxies/${x.id}/check`); } catch { } } renderProxies(); };
  $("#p-add").onclick = () => modal(`<h2>Додати проксі</h2><div class="field"><label>Один рядок = один проксі</label>
    <textarea id="lines" rows="6" placeholder="host:port:логін:пароль&#10;socks5://логін:пароль@host:port"></textarea></div>
    <div class="field"><label>Тип, якщо в рядку не вказано</label><select id="ty"><option>http</option><option>socks5</option></select></div>
    <div class="actions"><button class="btn" id="c">Скасувати</button><button class="btn primary" id="ok">Додати</button></div>`, m => {
    $("#c", m).onclick = closeModal;
    $("#ok", m).onclick = async () => { try { const r = await api("POST", "/ui-api/proxies", { lines: $("#lines", m).value, type: $("#ty", m).value }); closeModal(); toast(`Додано: ${r.ids.length}`); renderProxies(); } catch { } };
  });
}

// ---------- ЯДРА ----------
async function renderEngines() {
  const list = await (await fetch("/ui-api/engines")).json();
  const st = { approved: ["ok", "схвалене"], candidate: ["wait", "кандидат (тест на canary)"], revoked: ["bad", "відхилене"], retired: ["", "старе"] };
  $("#page").innerHTML = `<p class="note" style="margin-top:16px">Кожне нове ядро TYMX перевіряє сам: тричі запускає його на тимчасових профілях і дивиться, чи працює підміна, чи стабільний відбиток і чи не видно автоматизації. Перевірка повторюється й після кожного оновлення TYMX. Браузер відкривається лише зі <b>схваленого</b> ядра, чий хеш збігається із записаним. Нова версія спочатку додається як <b>кандидат</b> і працює лише на canary-профілях; коли вони відкрились без збоїв — схвалюєш її для всіх.</p>
  <div class="toolbar"><button class="btn primary" id="e-add">＋ Додати ядро</button></div>
  <div class="cards">${list.map(e => `<div class="card"><div style="display:flex;justify-content:space-between"><b>#${e.id} ${esc(e.version) || "ядро"}</b><span class="badge ${st[e.status][0]}">${st[e.status][1]}</span></div>
    <div class="mono" style="word-break:break-all;margin:8px 0">${esc(e.path)}</div><div class="mono">sha256: ${e.sha256.slice(0, 24)}…</div>
    ${selftestBlock(e)}
    ${e.status === "candidate" ? `<p class="note">Canary: успішно ${e.canary_ok_profiles} профілів, збоїв ${e.canary_fails}</p><div class="actions" style="justify-content:flex-start"><button class="btn primary sm" data-pro="${e.id}">Схвалити для всіх</button><button class="btn danger sm" data-rej="${e.id}">Відхилити</button></div>` : ""}</div>`).join("") || '<div class="empty">Ядер немає. Додай шлях до chrome.exe свого fingerprint-chromium.</div>'}</div>`;
  document.querySelectorAll("[data-pro]").forEach(b => b.onclick = async () => { try { await api("POST", `/ui-api/engines/${b.dataset.pro}/promote`, {}); renderEngines(); } catch { if (await confirmBox("Canary ще не пройдено. Схвалити все одно (на свій ризик)?")) { await api("POST", `/ui-api/engines/${b.dataset.pro}/promote`, { force: true }); renderEngines(); } } });
  document.querySelectorAll("[data-rej]").forEach(b => b.onclick = async () => { await api("POST", `/ui-api/engines/${b.dataset.rej}/reject`); renderEngines(); });
  document.querySelectorAll("[data-st]").forEach(b => b.onclick = async () => {
    b.disabled = true; b.textContent = "Перевіряю… (близько хвилини)";
    try { const r = await api("POST", `/ui-api/engines/${b.dataset.st}/selftest`); toast(r.ok ? "Ядро пройшло всі перевірки" : "Ядро не пройшло перевірку, дивись деталі", !r.ok); } catch { }
    renderEngines();
  });
  document.querySelectorAll("[data-stx]").forEach(b => b.onclick = () => { const el = $("#stx-" + b.dataset.stx); el.hidden = !el.hidden; });
  $("#e-add").onclick = () => modal(`<h2>Додати ядро</h2><div class="field"><label>Повний шлях до chrome.exe</label><input id="path" placeholder="D:\\fpchromium\\chrome.exe"></div>
    <div class="field"><label>Версія (для себе)</label><input id="ver" placeholder="148.0.7778.215"></div>
    <p class="hint">Перше ядро схвалюється одразу. Кожне наступне стає кандидатом і йде на canary-профілі.</p>
    <div class="actions"><button class="btn" id="c">Скасувати</button><button class="btn primary" id="ok">Додати</button></div>`, m => {
    $("#c", m).onclick = closeModal;
    $("#ok", m).onclick = async () => { $("#ok", m).textContent = "Рахую хеш…"; try { await api("POST", "/ui-api/engines", { path: $("#path", m).value.trim(), version: $("#ver", m).value.trim() }); closeModal(); renderEngines(); } catch { $("#ok", m).textContent = "Додати"; } };
  });
}

function selftestBlock(e) {
  const t = e.selftest;
  const head = !t ? `<span class="badge wait">ще не перевірене</span>`
    : `<span class="badge ${t.ok ? "ok" : "bad"}">${t.ok ? "✓ автоперевірка пройдена" : "✕ автоперевірка не пройдена"}</span> <small class="mono">${new Date(t.at * 1000).toLocaleString("uk-UA")}</small>`;
  const rows = t ? `<div id="stx-${e.id}" hidden class="stlist">${t.checks.map(c => `<div><span class="dot ${c.ok ? "ok" : "bad"}"></span><b>${esc(c.name)}</b> <small>${esc(c.detail)}</small></div>`).join("")}</div>` : "";
  return `<div class="st">${head}<div class="actions" style="justify-content:flex-start;margin-top:8px">${t ? `<button class="btn sm" data-stx="${e.id}">Деталі</button>` : ""}<button class="btn sm" data-st="${e.id}">Перевірити</button></div>${rows}</div>`;
}

// ---------- НАЛАШТУВАННЯ ----------
async function renderSettings() {
  const s = await (await fetch("/ui-api/settings")).json();
  const num = (k, label, hint) => `<div class="field"><label>${label}</label><input data-k="${k}" data-t="n" type="number" step="any" value="${s[k]}">${hint ? `<small class="note">${hint}</small>` : ""}</div>`;
  const chk = (k, label, hint) => `<div class="check"><input type="checkbox" data-k="${k}" data-t="b" ${s[k] ? "checked" : ""}><span>${label}<small>${hint}</small></span></div>`;
  $("#page").innerHTML = `<div class="settings" style="padding-top:16px">
    ${num("max_open", "Максимум вікон одночасно", "0 — без обмежень (∞). Нове вікно все одно не відкриється, якщо мало вільної RAM.")}
    ${num("launch_gap_sec", "Пауза між запусками, с", "Щоб не навантажувати комп'ютер, коли відкриваєш багато профілів.")}
    ${num("min_free_ram_gb", "Не відкривати нове вікно, якщо вільної RAM менше, ГБ", "")}` + `
    ${chk("webrtc_check", "Перевіряти WebRTC після запуску", "Якщо браузер світить справжній IP — він закривається, профіль не віддається.")}
    ${chk("strict_runtime_fp", "Звіряти відбиток у браузері з профілем", "Ядра, мова, часовий пояс. Увімкнено — звичайний Chromium без fingerprint-ядра не пройде (це правильно).")}
    <div class="field"><label>Додаткові ключі браузера (для тестів)</label><input data-k="engine_extra_args" data-t="s" value="${esc(s.engine_extra_args)}"></div>
    <h3 style="margin:22px 0 6px">Автооновлення</h3>
    <p class="note">Поточна версія TYMX: <b>${esc(S.version || "")}</b>. Нові версії приходять самі з каналу готових збірок TYMX. Поля нижче потрібні лише розробнику (закритий репозиторій з кодом).</p>
    <div class="field"><label>Репозиторій GitHub</label><input data-k="update_repo" data-t="s" value="${esc(s.update_repo)}" placeholder="логін/tymx"></div>
    <div class="field"><label>Токен GitHub (лише читання)</label><input data-k="update_token" data-t="s" type="password" value="${esc(s.update_token)}" placeholder="github_pat_…"></div>
    ${chk("update_auto_check", "Перевіряти оновлення автоматично", "При запуску й кожні 6 годин.")}
    ${chk("quit_on_close", "Закривати TYMX хрестиком повністю", "Закрив вікно, і TYMX вимикається разом з усіма відкритими профілями. Без галочки TYMX лишається працювати у фоні для скриптів.")}
    ${chk("update_auto_apply", "Ставити оновлення самостійно", "Коли не відкрито жодного профілю, TYMX сам оновиться й перезапуститься. Якщо профілі відкриті, з'явиться кнопка «Оновити зараз».")}
    <div class="actions" style="justify-content:flex-start"><button class="btn primary" id="save">Зберегти</button><button class="btn" id="upd-check">Перевірити оновлення</button></div></div>`;
  $("#upd-check").onclick = async () => { await saveSettings(); const r = await checkUpdate(true); if (r && r.configured && !r.available) toast(`У тебе остання версія ${r.current}`); };
  $("#save").onclick = async () => { await saveSettings(); toast("Збережено"); };
}
async function saveSettings() {
  const body = {}; document.querySelectorAll("[data-k]").forEach(el => body[el.dataset.k] = el.dataset.t === "b" ? el.checked : el.dataset.t === "n" ? +el.value : el.value);
  await api("PUT", "/ui-api/settings", body);
}

// ---------- бокова картка ----------
async function loadEngine() {
  try { const l = await (await fetch("/ui-api/engines")).json(); S.engine = l.find(e => e.status === "approved") || null; } catch { }
  selftestBar();
}
function drawSide() {
  const q = S.data.queue || {}, t = S.allTotal ?? S.data.total, e = S.engine;
  const pct = q.max_open ? Math.min(100, q.active / q.max_open * 100) : 0;
  $("#nav-count").textContent = t ?? "";
  $("#sidecard").innerHTML = `<div class="eng"><b>${e ? "Ядро " + esc(e.version || "#" + e.id) : "Ядро не додано"}</b><span class="pill ${e ? "" : "bad"}">${e ? "Активне" : "Немає"}</span></div>
    <div class="row"><span>Відкрито${(q.queued || []).length ? ` · у черзі ${q.queued.length}` : ""}</span><b>${q.active ?? 0} / ${q.max_open ? q.max_open : "∞"}</b></div>${q.max_open ? `<div class="bar"><div style="width:${pct}%"></div></div>` : ""}
    <div class="row"><span>Вільна RAM</span><b>${q.free_ram_gb ?? "–"} ГБ</b></div>`;
}

// ---------- API ДЛЯ БОТІВ ----------
function renderApi() {
  const base = `http://127.0.0.1:${location.port}`;
  $("#page").innerHTML = `<div class="settings" style="padding-top:16px;max-width:780px">
    <p class="note">TYMX відповідає так само, як локальний API AdsPower, тільки на своєму порту <b>${location.port}</b>. AdsPower лишається на 50325, тож обидві програми працюють разом. Щоб бот працював через TYMX, у його налаштуваннях заміни порт 50325 на ${location.port}.</p>
    <h3>Адреса</h3><div class="code">${base}</div>
    <h3>Відкрити профіль</h3><div class="code">${base}/api/v1/browser/start?user_id=&lt;ID профілю&gt;</div>
    <p class="note">У відповіді є <b>ws.puppeteer</b>: його передаєш у Playwright <b>connect_over_cdp</b>. Профіль віддається лише після того, як пройшов усі перевірки Safety gate.</p>
    <h3>Закрити профіль</h3><div class="code">${base}/api/v1/browser/stop?user_id=&lt;ID профілю&gt;</div>
    <h3>Список профілів</h3><div class="code">${base}/api/v1/user/list?page=1&amp;page_size=100</div>
    <p class="note">ID профілю видно в таблиці «Профілі», колонка ID.</p></div>`;
}

// ---------- ЖУРНАЛ ----------
async function renderJournal() {
  const ev = await (await fetch("/ui-api/events?limit=200")).json();
  $("#page").innerHTML = `<div class="tablewrap" style="margin-top:14px"><table><thead><tr><th>Час</th><th>№</th><th>Профіль</th><th>Дія</th><th>Результат</th><th>Деталі</th></tr></thead><tbody>
  ${ev.map(e => { const bad = (e.detail || []).filter(c => !c.ok); return `<tr><td class="mono">${fmtTime(e.ts)}</td><td class="num">${e.pseq ?? "—"}</td><td><b>${esc(e.pname || e.profile_id)}</b></td><td>${e.kind === "open" ? "відкриття" : esc(e.kind)}</td>
    <td><span class="badge ${e.ok ? "ok" : "bad"}">${e.ok ? "✔ успішно" : "✖ відмова"}</span></td><td style="color:var(--muted)">${esc(bad.map(c => c.name + ": " + c.detail).join("; ") || "усі перевірки пройдено")}</td></tr>`; }).join("") || `<tr><td colspan="6" class="empty">Запусків ще не було</td></tr>`}
  </tbody></table></div>`;
}

// ---------- SAFETY GATE ----------
async function renderGate() {
  const s = await (await fetch("/ui-api/settings")).json();
  $("#page").innerHTML = `<div class="settings" style="padding-top:16px;max-width:720px">
    <p class="note">Перед кожним відкриттям TYMX перевіряє профіль. Якщо хоч одна перевірка не пройшла, профіль <b>не відкриється</b>, а причина буде в колонці «Safety gate» і в «Журналі запусків».</p>
    <div class="card" style="margin-bottom:10px"><b>До запуску</b><ul class="note" style="margin:8px 0 0 18px;line-height:1.8">
      <li>Ядро на місці, і його хеш збігається зі схваленим (файл ніхто не підмінив).</li>
      <li>Відбиток профілю не змінювався з моменту створення.</li>
      <li>Проксі живий.</li><li>Країна й часовий пояс IP проксі збігаються з профілем.</li></ul></div>
    <div class="card" style="margin-bottom:16px"><b>Одразу після запуску</b><ul class="note" style="margin:8px 0 0 18px;line-height:1.8">
      <li>WebRTC не світить жодного IP: ${s.webrtc_check ? '<span class="ok-t">увімкнено</span>' : '<span class="bad-t">вимкнено</span>'}</li>
      <li>Браузер показує саме ті ядра процесора, мову й пояс, що в профілі: ${s.strict_runtime_fp ? '<span class="ok-t">увімкнено</span>' : '<span class="bad-t">вимкнено</span>'}</li></ul></div>
    <p class="note">Увімкнути чи вимкнути перевірки після запуску можна в «Налаштуваннях».</p></div>`;
}

$("#btn-quit").onclick = async () => {
  if (!await confirmBox("Вийти з TYMX? Усі відкриті профілі закриються.")) return;
  try { await fetch("/ui-api/quit", { method: "POST" }); } catch { }
  document.body.innerHTML = `<div style="margin:auto;text-align:center;color:var(--muted)"><h2 style="color:var(--text)">TYMX вимкнено</h2><p>Це вікно можна закрити. Запустити знову: ярлик TYMX на робочому столі.</p></div>`;
};

// ---------- АВТОПЕРЕВІРКА ЯДРА ----------
function selftestBar() {
  const t = S.engine && S.engine.selftest, bad = t && !t.ok;
  let bar = $("#st-bar");
  if (!bad) { if (bar) bar.remove(); return; }
  if (bar) return;
  bar = document.createElement("div"); bar.id = "st-bar"; bar.className = "update-bar bad";
  bar.innerHTML = `<span>Автоперевірка основного ядра <b>не пройдена</b>: сайти можуть помітити, що профілі несправжні. Не відкривай важливі акаунти, поки не розберемось.</span><button class="btn sm" id="st-go">Деталі</button>`;
  $("main").insertBefore(bar, $("#page"));
  $("#st-go").onclick = () => go("engines");
}

// ---------- АВТООНОВЛЕННЯ ----------
async function checkUpdate(manual) {
  let r;
  try { r = await api("GET", "/ui-api/update/check"); } catch { return null; }
  if (!r.configured) { if (manual) toast("Спершу впиши репозиторій і токен", true); return r; }
  if (r.available) { showUpdateBar(r); markUpdBtn(r); }
  return r;
}
function markUpdBtn(r) {
  const b = $("#btn-upd"); if (!b) return;
  b.classList.add("primary"); b.querySelector("span").textContent = `Оновити до ${r.latest}`;
}
$("#btn-upd").onclick = async () => {
  const b = $("#btn-upd");
  if (b.classList.contains("primary") && $("#upd-go")) return $("#upd-go").click();
  b.disabled = true; b.querySelector("span").textContent = "Перевіряю…";
  const r = await checkUpdate(false);
  b.disabled = false;
  if (r && r.available) return;
  b.querySelector("span").textContent = "Оновлення";
  if (!r) return toast("Не вдалося перевірити оновлення, спробуй пізніше", true);
  if (!r.configured) { toast("Спершу впиши репозиторій і токен у «Налаштуваннях»", true); return go("settings"); }
  toast(`У тебе остання версія ${r.current}`);
};
function showUpdateBar(r) {
  if ($("#update-bar")) return;
  const bar = document.createElement("div"); bar.id = "update-bar"; bar.className = "update-bar";
  bar.innerHTML = `<span>Доступна нова версія TYMX <b>${esc(r.latest)}</b> (у тебе ${esc(r.current)}).</span><button class="btn primary sm" id="upd-go">Оновити зараз</button>`;
  $("main").insertBefore(bar, $("#page"));
  $("#upd-go").onclick = async () => {
    if (!await confirmBox(`Оновити TYMX до ${r.latest}? Відкриті профілі закриються, програма перезапуститься сама.`)) return;
    $("#upd-go").disabled = true; $("#upd-go").textContent = "Оновлюю…";
    try { await api("POST", "/ui-api/update/apply"); } catch { $("#upd-go").disabled = false; $("#upd-go").textContent = "Оновити зараз"; return; }
    bar.querySelector("span").textContent = "Встановлюю оновлення і перезапускаю TYMX…";
    const until = Date.now() + 90000;
    const wait = async () => {
      try { const w = await (await fetch("/ui-api/whoami", { cache: "no-store" })).json(); if (w.version === r.latest) return location.reload(); } catch { }
      if (Date.now() < until) setTimeout(wait, 1500); else bar.querySelector("span").textContent = "Не дочекався перезапуску. Закрий вікно і відкрий TYMX ярликом.";
    };
    setTimeout(wait, 2500);
  };
}
fetch("/ui-api/whoami").then(r => r.json()).then(w => { S.version = w.version; }).catch(() => { });
fetch("/ui-api/settings").then(r => r.json()).then(s => { if (s.update_auto_check) { checkUpdate(false); setInterval(() => checkUpdate(false), 6 * 3600 * 1000); } }).catch(() => { });

setInterval(() => { if (!modalOpen() && !document.querySelector(".menu")) refresh(); }, 3000);
setInterval(loadEngine, 15000);
// вікно відкрите: TYMX не відкриватиме ще одне, коли скрипт запускає профілі через API
const WIN = Math.random().toString(36).slice(2);
const ping = () => fetch("/ui-api/ping?w=" + WIN).catch(() => { }); ping(); setInterval(ping, 20000);
// вікно закривають: одразу кажемо серверу, щоб наступний профіль від скрипта знову показав TYMX
addEventListener("pagehide", () => { try { navigator.sendBeacon("/ui-api/ping?closed=1&w=" + WIN); } catch { } });
loadEngine().then(drawSide);
go("profiles");
